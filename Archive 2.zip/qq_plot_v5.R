#Generic QQ plot function with concentration bands, for either P-values or chi-sq values
#Function written by Mike Weale and Tom Price, King's College London.
#Version 5 (1 Nov 2011) uses "lower.tail=FALSE" in both pchisq and qchisq calls to avoid NaNs when p is very small
#Concentration bands are plotted using the pointwise method of Quesenberry & Hale (1980) J. Statist. Comput. Simul. 11:41-53
#The method proceeds from noting that the kth order statistic from a sample of n i.i.d. U(0,1) statistics has a Beta(k,n+1-k) distribution.
#Arguments:
#x		the data vector to be plotted
#alpha	the alpha level for the concentration band (if plotted)
#datatype	"pvalue" (default) indicates x contains p-values.  "chisq" indicates x contains chi-square values.  "stdnorm" indicates x contains z values.
#scaletype	"pvalue" (default) indicates x- and y-axis scale to be in -log10(p-value) units.  "quantile" indicates x- and y-axis scale to be in quantile units.  Note if datatype="stdnorm" then scaletype is forced ="quantile"
#df		degrees of freedom for chi-square scale used in Q-Q plot.  Default=2 (equivalent to -log10(p-value) transformation)
#plot.concentration.band	Flag to indicate whether concentration band is to be plotted.  Default=TRUE.
#one.sided				Flab to indicate if one-sided (upper) or two-sided concentration band required.  Default=FALSE
#print	If set, a dataframe of O and E values are returned.  Default=FALSE
#xat		If set, a vector seting x tick positions. For p-values, sets 10^x positions
#yat		If set, a vector seting y tick positions. For p-values, sets 10^y positions
# ...		other graphical parameters to be passed to plot function
#Returns (if print==TRUE):
#Dataframe with two columns: $O=sorted observed values, $E=sorted expected values
#e.g.
#p = pnorm(c(rnorm(1e4),rnorm(10)-5))  #mixture of 'null' and 'hit' p-values
#qq.plot(p)
#
qq.plot <- function( x, alpha=0.05, datatype="pvalue", scaletype="pvalue", df=2, plot.concentration.band=TRUE, one.sided=FALSE, print=FALSE, xat=NULL, yat=NULL, main=paste("Q-Q plot (on chisq[",df,"]) of " ,pname, sep=""), xlab="Expected quantile", ylab="Observed quantile", pch="x", cex=0.5, col="black", ... )
{
  pname <- paste(deparse(substitute(x), 500), collapse="\n")
  if (!is.numeric(x))
    stop("'x' must be numeric")
  nmissing = sum(is.na(x))
  x <- x[ !is.na(x) ]                 #To deal with missing data values (these don't get plotted)
  if ((datatype=="pvalue")&((min(x)<0)|(max(x)>1)))
    stop("'x' must be >=0 and <=1")
  if ((datatype=="chisq")&(min(x)<0))
    stop("'x' must be >=0")
  nzero = sum(x==0)
  if ((nmissing+nzero>0)&(datatype=="pvalue"))
    warning(nmissing, " missing values (excluded) & ", nzero, " zero values (included but not plotted)")
  if ((nmissing>0)&(datatype!="pvalue"))
    warning(nmissing, " missing values (excluded)")
  if (datatype=="stdnorm") {df=0; scaletype="ordinal"}
  n <- length(x)
  a <- (1:n)
  b <- n-a+1
  #Find E and O under relevant inv. chisq transformation
  if ((df==2)&(datatype!="stdnorm")) {
    E <- -2*log(a/(n+1))                           #short-cut for df=2: use -2log-transformed expected U(0,1) order statistics (low p -> high score)
    if (datatype=="pvalue") O <- -2*log(sort(x))   #Note obs data no need to transform if already chisq or z value (high values first)
  } else {
    if (datatype=="stdnorm") E <- qnorm(a/(n+1),lower.tail=FALSE)           #invnorm-transformed expected U(0,1) order statistics (put high scores first)
    if (datatype!="stdnorm") E <- qchisq(a/(n+1),df=df,lower.tail=FALSE)    #invchisq-transformed expected U(0,1) order statistics (low p -> high score)
    if (datatype=="pvalue") O <- qchisq(sort(x),df=df,lower.tail=FALSE)     #Note transform obs data only needed for pvalue datatype
  }
  if (datatype!="pvalue") O <- sort(x, decreasing=TRUE)       #Sort x, high values first
  #Do Q-Q plot, derive "pretty" tick places for log10 p-value scale, if necessary
  if (scaletype=="pvalue") {
    if (!is.null(xat)) x4Lx=xat  else x4Lx = pretty( -log10(pchisq(c(E[1],E[n]),df=df,lower.tail=FALSE)) )
    if (!is.null(yat)) y4Ly=yat  else y4Ly = pretty( -log10(pchisq(c(O[1],O[n-nzero]),df=df,lower.tail=FALSE)) )  #"+nzero" avoids p=0 values
    xnums = qchisq(10^-x4Lx,df=df,lower.tail=FALSE)                       #Get same locations on actual chisq scale
    ynums = qchisq(10^-y4Ly,df=df,lower.tail=FALSE)                       #Get same locations on actual chisq scale
    Lx <- parse( text=paste("10^-",x4Lx,sep="") )
    Ly <- parse( text=paste("10^-",y4Ly,sep="") )
  } else {
    if (!is.null(xat)) xnums=xat else xnums=pretty(E)
    if (!is.null(yat)) ynums=yat else ynums=pretty(O)
    Lx <- parse( text=as.character(xnums) )
    Ly <- parse( text=as.character(ynums) )
  }
  plot( E, O, main = main, xlab = xlab, ylab = ylab, type = "n", xaxt = "n", yaxt = "n", ... )
  axis(1, at=xnums, labels=Lx )
  axis(2, at=ynums, labels=Ly )
  if (plot.concentration.band==TRUE) {
    if (one.sided==FALSE) {
      upper <- qbeta( 1-alpha/2, a, b )      #Exp. upper CL from ith U(0,1) order statistic (becomes lower CL under trans)
      lower <- qbeta( alpha/2, a, b )        #Exp. lower CL from ith U(0,1) order statistic (becomes upper CL under trans)
    } else {
      upper <- rep( 1, n )                   #Exp. upper CL from ith U(0,1) order statistic (becomes lower CL under trans)
      lower <- qbeta( alpha, a, b )          #Exp. lower CL from ith U(0,1) order statistic (becomes upper CL under trans)
    }
    if (df==2) {
      polygon( c( E, rev(E) ), c( -2*log(upper), rev(E) ), col="grey", border = NA )  #lower band after trans
      polygon( c( E, rev(E) ), c( -2*log(lower), rev(E) ), col="grey", border = NA )  #upper band after trans
    } else {
      if (datatype=="stdnorm") {
        polygon( c( E, rev(E) ), c( qnorm(upper,lower.tail=FALSE), rev(E) ), col="grey", border = NA )  #lower band after trans
        polygon( c( E, rev(E) ), c( qnorm(lower,lower.tail=FALSE), rev(E) ), col="grey", border = NA ) #upper band after trans
      } else {
        polygon( c( E, rev(E) ), c( qchisq(upper,df=df,lower.tail=FALSE), rev(E) ), col="grey", border = NA )  #lower band after trans
        polygon( c( E, rev(E) ), c( qchisq(lower,df=df,lower.tail=FALSE), rev(E) ), col ="grey", border = NA ) #upper band after trans
      }
    }
  }
  abline( 0, 1, col="red" )  #plot 1:1 line
  abline(h=ynums, v=xnums, col="lightgray", lty="dotted")  #plot grid
  points( E, O, pch=pch, cex=cex, col=col )  #plot points
  if (print==TRUE) return( data.frame( O=O, E=E ) )
}
